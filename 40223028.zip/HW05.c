//40223028 - ZAHRA HEYDARI
#include <stdio.h>
int main()
{
    int n;
    printf("Enter n: ");
    scanf("%d",&n);
    if (n <= 0){
        printf("NOT VALID input");
    }else{
        printf("Enter string: ");
        char string[n];
        scanf("%s",string);

        int len = n;
        int i = 0;
        while( i <= (len-1))
        {
            if (string[i] == string[i+1])
            {   
                //change the string
                for (int j = i ; j<=(len-1) ; j++)
                {
                    string[j] = string[j+2];
                }
                string[len-1] = '\0';
                string[len-2] = '\0';
                len -= 2;
                printf("%s\n",string);

                //start again
                i = 0;
            }else{
                i++;
            }
        }
        
    }


    return 0;
}
